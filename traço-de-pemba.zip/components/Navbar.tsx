/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useState } from 'react';

interface NavbarProps {
  onNavClick: (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    setMobileMenuOpen(false);
    onNavClick(e, targetId);
  };

  return (
    <>
      <nav className="sticky top-0 bg-white py-6 border-b border-brandSoftBlue/10 z-50">
        <div className="max-w-[1800px] mx-auto px-8 flex items-center justify-between">
          {/* Logo - Styled identically to the sharp serif display mark in the attached image */}
          <a 
            href="#" 
            onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
                onNavClick(e, ''); // Pass empty string to just reset to home
            }}
            className="z-50 relative focus:outline-none block"
          >
            <img 
              src="/input_file_0.png" 
              alt="Traço de Pemba" 
              className="h-10 md:h-12 w-auto object-contain" 
              referrerPolicy="no-referrer"
            />
          </a>
          
          {/* Center Links - Desktop - Montserrat, extra spacing, delicate, size smaller */}
          <div className="hidden md:flex items-center gap-10 text-[11px] font-medium tracking-[0.2em] uppercase text-brandPrussian/80">
            <a href="#products" onClick={(e) => handleLinkClick(e, 'products')} className="hover:text-brandRed transition-colors">Coleções</a>
            <a href="#about" onClick={(e) => handleLinkClick(e, 'about')} className="hover:text-brandRed transition-colors">Sobre Nós</a>
            <a href="#journal" onClick={(e) => handleLinkClick(e, 'journal')} className="hover:text-brandRed transition-colors">Fundamento</a>
            <a href="#contact" onClick={(e) => handleLinkClick(e, 'contact')} className="hover:text-brandRed transition-colors">Contato</a>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-6 z-50 relative text-brandPrussian">
            {/* Mobile Menu Toggle */}
            <button 
              className="block md:hidden focus:outline-none text-brandPrussian"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
               {mobileMenuOpen ? (
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                 </svg>
               ) : (
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                 </svg>
               )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-white z-40 flex flex-col justify-center items-center transition-all duration-500 ease-in-out ${
          mobileMenuOpen ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 -translate-y-10 pointer-events-none'
      }`}>
          <div className="flex flex-col items-center space-y-8 text-sm font-medium tracking-[0.2em] uppercase text-brandPrussian">
            <a href="#products" onClick={(e) => handleLinkClick(e, 'products')} className="hover:text-brandRed transition-colors">Coleções</a>
            <a href="#about" onClick={(e) => handleLinkClick(e, 'about')} className="hover:text-brandRed transition-colors">Sobre Nós</a>
            <a href="#journal" onClick={(e) => handleLinkClick(e, 'journal')} className="hover:text-brandRed transition-colors">Fundamento</a>
            <a href="#contact" onClick={(e) => handleLinkClick(e, 'contact')} className="hover:text-brandRed transition-colors">Contato</a>
          </div>
      </div>
    </>
  );
};

export default Navbar;
